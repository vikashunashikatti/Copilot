export class Employee {
    name!: string;
    id!: number;
    contactnumber!: number;
    email!: string;
    salary!: number;
  }
  