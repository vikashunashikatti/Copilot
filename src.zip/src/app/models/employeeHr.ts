export class EmployeeHr {
    name!: string;
    id!: number;
    contactnumber!: number;
    email!: string;
    department!: string;
    employeeList!:Array<string>;
  }
  