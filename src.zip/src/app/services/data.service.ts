import { Injectable } from '@angular/core';
import { BehaviorSubject, Observable } from 'rxjs';
import { HttpClient, HttpErrorResponse } from '@angular/common/http';
import { Employee } from '../models/employee';

@Injectable()
export class DataService {
  private readonly API_URL = 'http://3.93.13.154:8080/employee';
  private readonly API_URL_HR = 'http://3.93.13.154:8080/Manager';

  dataChange: BehaviorSubject<Employee[]> = new BehaviorSubject<Employee[]>([]);
  // Temporarily stores data from dialogs
  dialogData: any;

  constructor(private httpClient: HttpClient) {

  }

  get data(): Employee[] {
    return this.dataChange.value;
  }

  getDialogData() {
    return this.dialogData;
  }

  /** CRUD METHODS */
  getAllEmployees(){
    return this.httpClient.get(this.API_URL);
    // .subscribe(data => {
    //   //this.dataChange.next(data);
    //   console.log(data);
    // },
    // (error: HttpErrorResponse) => {
    // console.log (error.name + ' ' + error.message);
    // });
  }

  getAllManagers() {
    return this.httpClient.get(this.API_URL_HR);
  }

  deleteEmployee(id: number) {
    return this.httpClient.delete(this.API_URL + "/removeEmp/" + id);
  }
  deleteHr(id: number) {
    return this.httpClient.delete(this.API_URL_HR + "/deleteManager/" + id);
  }
  // DEMO ONLY, you can find working methods below
  addEmployee(Employee: Employee) {
    const body = JSON.stringify(Employee);
    return this.httpClient.post(this.API_URL + "/addEmp", body);

    //this.dialogData = Employee;

  }

  addManager(Employee: Employee) {
    const body = JSON.stringify(Employee);
    return this.httpClient.post(this.API_URL_HR + "/addManager", body);

    //this.dialogData = Employee;

  }

  updateEmployee(Employee: Employee, EmpOrHR: any) {
    //this.dialogData = Employee;
    if (EmpOrHR) {
      const body = Employee;
      return this.httpClient.put(this.API_URL_HR + "/updateManager/" + Employee.id, body);
    } else {
      const body = Employee;
      return this.httpClient.put(this.API_URL + "/updateEmp/" + Employee.id, body);
    }
  }


  // deleteEmployee(id: number): void {
  //   console.log(id);
  // }
}



/* REAL LIFE CRUD Methods I've used in projects. ToasterService uses Material Toasts for displaying messages:

    // ADD, POST METHOD
    addItem(kanbanItem: KanbanItem): void {
    this.httpClient.post(this.API_URL, kanbanItem).subscribe(data => {
      this.dialogData = kanbanItem;
      this.toasterService.showToaster('Successfully added', 3000);
      },
      (err: HttpErrorResponse) => {
      this.toasterService.showToaster('Error occurred. Details: ' + err.name + ' ' + err.message, 8000);
    });
   }

    // UPDATE, PUT METHOD
     updateItem(kanbanItem: KanbanItem): void {
    this.httpClient.put(this.API_URL + kanbanItem.id, kanbanItem).subscribe(data => {
        this.dialogData = kanbanItem;
        this.toasterService.showToaster('Successfully edited', 3000);
      },
      (err: HttpErrorResponse) => {
        this.toasterService.showToaster('Error occurred. Details: ' + err.name + ' ' + err.message, 8000);
      }
    );
  }

  // DELETE METHOD
  deleteItem(id: number): void {
    this.httpClient.delete(this.API_URL + id).subscribe(data => {
      console.log(data['']);
        this.toasterService.showToaster('Successfully deleted', 3000);
      },
      (err: HttpErrorResponse) => {
        this.toasterService.showToaster('Error occurred. Details: ' + err.name + ' ' + err.message, 8000);
      }
    );
  }
*/





