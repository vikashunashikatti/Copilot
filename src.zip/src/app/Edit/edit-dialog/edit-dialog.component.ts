import { MAT_DIALOG_DATA, MatDialogRef } from '@angular/material/dialog';
import {Component, Inject} from '@angular/core';
import {FormControl, Validators} from '@angular/forms';
import { DataService } from 'src/app/services/data.service';

@Component({
  selector: 'app-edit-dialog',
  templateUrl: './edit-dialog.component.html',
  styleUrls: ['./edit-dialog.component.scss']
})
export class EditDialogComponent {
  department:boolean;
  salary:boolean =false;
  mobNumberPattern = "^((\\+91-?)|0)?[0-9]{10}$";
  emailValid: boolean=false;
  constructor(public dialogRef: MatDialogRef<EditDialogComponent>, @Inject(MAT_DIALOG_DATA) public data: any,
  public dataService: DataService
              ) { 
                if(this.data.hr) {
                  this.department= true;
                  this.salary= false;
                } else {
                  this.department= false;
                  this.salary= true;
                } 

              }

  formControl = new FormControl('', [
    Validators.required
    // Validators.email,
  ]);
  checkMail() {
    if(this.data.email) {
      let regex = new RegExp('[a-z0-9]+@[a-z]+\.[a-z]{2,3}');
      if(regex.test(this.data.email)){
        this.emailValid= false;
      } else {
        this.emailValid= true;
        // this.formControl.hasError('email');
      }
    }
  }
  onKeyUp(event: any,fieldName:string) {
    if(fieldName=='salary') {
      this.data.salary= event.target.value.replace(/[^0-9]*/g, '');
    } else {
    this.data.contactnumber= event.target.value.replace(/[^0-9]*/g, '');
    }
  }
  getErrorMessage() {
    return this.formControl.hasError('required') ? 'Required field' :
      this.formControl.hasError('email') ? 'Not a valid email' :
        '';
  }

  submit() {
    // emppty stuff
  }

  onNoClick(): void {
    this.dialogRef.close();
  }

  stopEdit(): void {
    this.dataService.updateEmployee(this.data,this.data.hr).subscribe(
      data=>{
        console.log("Updated data"+this.data);
      }
    );
  }
}
